
import type { HouseData } from './types';

export const HOUSE_DATA: HouseData[] = [
  { id: 1, sqft: 1500, bedrooms: 3, bathrooms: 2, price: 300000 },
  { id: 2, sqft: 1250, bedrooms: 2, bathrooms: 2, price: 250000 },
  { id: 3, sqft: 2200, bedrooms: 4, bathrooms: 3, price: 450000 },
  { id: 4, sqft: 1800, bedrooms: 3, bathrooms: 2.5, price: 380000 },
  { id: 5, sqft: 3100, bedrooms: 5, bathrooms: 4, price: 620000 },
  { id: 6, sqft: 950, bedrooms: 2, bathrooms: 1, price: 210000 },
  { id: 7, sqft: 2500, bedrooms: 4, bathrooms: 3, price: 510000 },
  { id: 8, sqft: 1650, bedrooms: 3, bathrooms: 2, price: 345000 },
  { id: 9, sqft: 2750, bedrooms: 4, bathrooms: 3.5, price: 550000 },
  { id: 10, sqft: 1100, bedrooms: 2, bathrooms: 1.5, price: 235000 },
  { id: 11, sqft: 3500, bedrooms: 5, bathrooms: 4.5, price: 700000 },
  { id: 12, sqft: 1900, bedrooms: 3, bathrooms: 2.5, price: 400000 },
  { id: 13, sqft: 2100, bedrooms: 4, bathrooms: 2, price: 430000 },
  { id: 14, sqft: 1400, bedrooms: 2, bathrooms: 2, price: 290000 },
  { id: 15, sqft: 2900, bedrooms: 4, bathrooms: 3, price: 590000 },
];
