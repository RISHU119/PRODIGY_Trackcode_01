
import React, { useState, useCallback } from 'react';
import { HOUSE_DATA } from './constants';
import { predictHousePrice } from './services/geminiService';
import type { PredictionParams } from './types';
import Header from './components/Header';
import InputControl from './components/InputControl';
import PriceDisplay from './components/PriceDisplay';
import RegressionChart from './components/RegressionChart';
import DataTable from './components/DataTable';
import { CalculatorIcon } from './components/icons/CalculatorIcon';

function App(): React.ReactNode {
  const [params, setParams] = useState<PredictionParams>({
    sqft: 2000,
    bedrooms: 3,
    bathrooms: 2.5,
  });
  const [predictedPrice, setPredictedPrice] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setParams(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
  };

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setPredictedPrice(null);

    try {
      const price = await predictHousePrice(params);
      setPredictedPrice(price);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [params]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          
          {/* Left Column: Prediction Form and Result */}
          <div className="lg:col-span-2 bg-white p-6 md:p-8 rounded-2xl shadow-lg border border-slate-200">
            <h2 className="text-2xl font-bold text-slate-700 mb-6">Enter House Details</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <InputControl
                label="Square Footage"
                name="sqft"
                type="number"
                value={params.sqft}
                onChange={handleInputChange}
                placeholder="e.g., 2000"
              />
              <InputControl
                label="Bedrooms"
                name="bedrooms"
                type="number"
                value={params.bedrooms}
                onChange={handleInputChange}
                placeholder="e.g., 3"
              />
              <InputControl
                label="Bathrooms"
                name="bathrooms"
                type="number"
                step="0.5"
                value={params.bathrooms}
                onChange={handleInputChange}
                placeholder="e.g., 2.5"
              />
              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-300 transition-all duration-300 disabled:bg-indigo-400 disabled:cursor-not-allowed"
              >
                <CalculatorIcon />
                {isLoading ? 'Calculating...' : 'Predict Price'}
              </button>
            </form>
            <PriceDisplay predictedPrice={predictedPrice} isLoading={isLoading} error={error} />
          </div>

          {/* Right Column: Data Visualization */}
          <div className="lg:col-span-3 space-y-8">
            <div className="bg-white p-6 md:p-8 rounded-2xl shadow-lg border border-slate-200 h-[400px]">
              <h2 className="text-2xl font-bold text-slate-700 mb-6">Price vs. Square Footage</h2>
              <RegressionChart data={HOUSE_DATA} />
            </div>
            <div className="bg-white p-6 md:p-8 rounded-2xl shadow-lg border border-slate-200">
               <h2 className="text-2xl font-bold text-slate-700 mb-6">Sample Training Data</h2>
              <DataTable data={HOUSE_DATA} />
            </div>
          </div>
        </div>
      </main>
      <footer className="text-center p-4 mt-8 text-slate-500 text-sm">
        <p>Powered by React, Tailwind CSS, and Google Gemini.
        </p>
      </footer>
    </div>
  );
}

export default App;
