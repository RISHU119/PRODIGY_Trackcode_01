
import { GoogleGenAI, Type } from "@google/genai";
import { HOUSE_DATA } from '../constants';
import type { PredictionParams } from '../types';

// This check is to prevent crashing in environments where process.env is not defined.
const apiKey = typeof process !== 'undefined' && process.env && process.env.API_KEY
  ? process.env.API_KEY
  : '';

if (!apiKey) {
  console.warn("API_KEY environment variable not found. App will not be able to connect to Gemini.");
}

const ai = new GoogleGenAI({ apiKey });

export const predictHousePrice = async ({ sqft, bedrooms, bathrooms }: PredictionParams): Promise<number> => {
    if (!apiKey) {
        throw new Error("API key is not configured. Please set the API_KEY environment variable.");
    }
    const dataString = JSON.stringify(HOUSE_DATA, null, 2);

    const prompt = `
        You are a data scientist specializing in real estate predictive modeling.
        Based on the following dataset of historical house sales, perform a multiple linear regression analysis to predict the price of a new house.

        Historical Data:
        ${dataString}

        New House to Predict:
        - Square Footage: ${sqft}
        - Bedrooms: ${bedrooms}
        - Bathrooms: ${bathrooms}

        Calculate the predicted price and return ONLY a JSON object with the key "predictedPrice". Do not include any other text, explanations, or markdown formatting. The price should be a number.
    `;

    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            predictedPrice: {
                type: Type.NUMBER,
                description: "The predicted market price of the house.",
            },
        },
        required: ["predictedPrice"],
    };

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
                temperature: 0.2, // Lower temperature for more deterministic pricing
            },
        });
        
        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText);

        if (result && typeof result.predictedPrice === 'number') {
            return result.predictedPrice;
        } else {
            console.error("Parsed JSON:", result);
            throw new Error("Invalid response format from Gemini API. Expected { predictedPrice: number }.");
        }

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        // Provide a more user-friendly error message
        if (error instanceof Error && error.message.includes('API key not valid')) {
             throw new Error("The provided API key is not valid. Please check your configuration.");
        }
        throw new Error("Failed to get prediction from the AI model. The service may be temporarily unavailable.");
    }
};
