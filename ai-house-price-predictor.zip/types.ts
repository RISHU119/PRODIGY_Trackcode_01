
export interface HouseData {
  id: number;
  sqft: number;
  bedrooms: number;
  bathrooms: number;
  price: number;
}

export interface PredictionParams {
  sqft: number;
  bedrooms: number;
  bathrooms: number;
}
